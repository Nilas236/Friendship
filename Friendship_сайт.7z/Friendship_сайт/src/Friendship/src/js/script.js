import tabs from './tabs';
import list from './list';

window.addEventListener('DOMContentLoaded', function(){

    tabs('')
    list();
});