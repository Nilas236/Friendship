import {getResource} from '../services/services'; 
function info() {
    class ListBlock { 
        constructor(title, subtitle, code, rules, parentSelector, ...classes) { 
            this.title = title;
            this.subtitle = subtitle;
            this.code = code;
            this.rules = rules;
            this.classes = classes;
            this.parent = document.querySelector(parentSelector);
        }


        render() { 
            const element = document.createElement('div'); 

            if (this.classes.length === 0) { 
                this.classes = "list-info"; 
                element.classList.add(this.classes);
            } else { 
                this.classes.forEach(className => element.classList.add(className)); 
            }

            element.innerHTML = `
                <div class="list-info__title">${this.title}</div>
                <div class="list-info__subtitle">${this.subtitle}</div>
                <div class="list-block">
                    <div class="list-block__code">${this.code}</div>
                    <div class="list-block__rules">${this.rules}</div>
                </div>
            `; 
            this.parent.append(element);
        }
    }

    getResource('http://localhost:3000/list')  
        .then(data => {
            data.forEach(({title, subtitle, code, rules}) => {
                new ListBlock(title, subtitle, code, rules, ".list .container").render(); 
            });
        });
}

export default info;